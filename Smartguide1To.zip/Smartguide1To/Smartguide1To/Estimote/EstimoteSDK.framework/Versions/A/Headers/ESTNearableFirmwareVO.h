//
//  ESTNearableFirmwareVO.h
//  EstimoteSDK
//
//  Created by Marcin Klimek on 30/01/15.
//  Copyright (c) 2015 Estimote. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ESTNearableFirmwareVO : NSObject

@property (nonatomic, strong) NSNumber *firmwareId;
@property (nonatomic, strong) NSString *firmwareName;

@end
