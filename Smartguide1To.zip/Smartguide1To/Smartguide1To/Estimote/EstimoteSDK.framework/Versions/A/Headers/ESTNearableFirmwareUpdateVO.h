//
//  Copyright © 2015 Estimote. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ESTNearableFirmwareUpdateVO : NSObject

@end
