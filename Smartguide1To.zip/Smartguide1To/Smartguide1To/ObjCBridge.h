//
// Please report any problems with this app template to contact@estimote.com
//

#import <EstimoteSDK/EstimoteSDK.h>
#import <EstimoteSDK/ESTRequestBeaconDetails.h>
